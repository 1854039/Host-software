package com.example.zosdemo.domain;

public class JCLInfo {
    private String JESMSGLG;
    private String JESJCL;
    private String JESYSMSG;
    private String SYSPRINT;
    private String status;
    public void setJESMSGLG(String JESMSGLG){ this.JESMSGLG = JESMSGLG; }
    public String getJESMSGLG(){ return this.JESMSGLG; }
    public void setJESJCL(String JESJCL){ this.JESJCL = JESJCL; }
    public String getJESJCL() { return this.JESJCL; }
    public void setJESYSMSG(String JESYSMSG){ this.JESYSMSG = JESYSMSG; }
    public String getJESYSMSG(){ return this.JESYSMSG; }
    public void setSYSPRINT(String SYSPRINT){ this.SYSPRINT = SYSPRINT; }
    public String getSYSPRINT(){ return this.SYSPRINT; }
}
