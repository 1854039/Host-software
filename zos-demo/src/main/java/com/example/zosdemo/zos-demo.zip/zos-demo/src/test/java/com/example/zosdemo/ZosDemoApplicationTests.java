package com.example.zosdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZosDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
