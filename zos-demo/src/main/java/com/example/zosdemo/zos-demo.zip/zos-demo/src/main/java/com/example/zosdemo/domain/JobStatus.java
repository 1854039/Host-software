package com.example.zosdemo.domain;

public class JobStatus {

}
